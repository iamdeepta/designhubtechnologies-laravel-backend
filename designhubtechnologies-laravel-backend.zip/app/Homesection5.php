<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Homesection5 extends Model
{
    protected $table = 'tbl_homesection5';
    protected $primaryKey = 'homesection5_id';
    public $incrementing = true;
    protected $keyType = 'int';
    public $timestamps = false;

    // protected $attributes = [
    //     'homesection1_category' => '',
    //     'homesection1_image1' => '',
    //     'homesection1_image5' => '',
    //     'homesection1_image5' => '',
    //     'homesection1_image4' => '',
    // ];

    //protected $fillable = ['homesection1_category', 'homesection1_image1', 'homesection1_image5', 'homesection1_image5', 'homesection1_image4'];
    
}
